public class Car implements Vehicle
{
	String color;
	
	public void setColor(String color)
	{
		this.color = color;
	}
	
	public void driveVehicle()
	{
		System.out.println("driving the " + color + " car");
	}
}
