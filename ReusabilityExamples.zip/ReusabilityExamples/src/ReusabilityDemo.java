import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ReusabilityDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*Person p1 = new Person(new Car());
		p1.dispPerson();
		
		Person p2 = new Person(new Tractor());
		p2.dispPerson();*/
		
		/*ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		Person p1 = (Person) context.getBean("per1");
		p1.dispPerson();*/
		/*System.out.println("---------------------");
		Person p11 = (Person) context.getBean("per1");
		p11.dispPerson();*/
		
		/*Person p2 = (Person) context.getBean("per2");
		p2.dispPerson();*/
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(VehicleConfig.class);
		Person p1 = (Person) ctx.getBean("perc");
		p1.dispPerson();
		
		Person p2 = (Person) ctx.getBean("perc");
		p2.dispPerson();
		
		/*Person p2 = (Person) ctx.getBean("pert");
		p2.dispPerson();*/
		
		/*Person p3 = (Person) ctx.getBean("perx");
		p3.dispPerson();*/
	}
}

