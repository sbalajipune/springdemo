public class Person
{
	String personName;
	Vehicle v;
	Person(String personName, Vehicle v)
	{
		this.personName = personName;
		this.v = v;
	}
	public void dispPerson()
	{
		System.out.println("My name is " + this.personName + " And I'm ");
		v.driveVehicle();
		this.personName = "Amoli";
		System.out.println("Name changed to " + this.personName);
	}
	
	public void clean() throws Exception {
		System.out.println("Person getting destroyed");
	}
	
	public void init() throws Exception {
		System.out.println("Object is created");
	}
}
