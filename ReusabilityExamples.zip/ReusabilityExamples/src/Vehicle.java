
public interface Vehicle
{
	public void driveVehicle();
}
