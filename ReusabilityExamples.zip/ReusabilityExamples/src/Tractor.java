
public class Tractor implements Vehicle
{
	public void driveVehicle()
	{
		System.out.println("Driving tractor");
	}
	
	public void driveTractor()
	{
		System.out.println("Tractor");
	}
}
